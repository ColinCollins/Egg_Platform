﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CfgCheck;

namespace CfgCheck
{
    public static class AssertExtensions
    {
        
    }
}
