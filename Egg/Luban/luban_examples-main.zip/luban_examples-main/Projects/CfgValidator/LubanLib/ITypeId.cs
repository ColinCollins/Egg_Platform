﻿namespace Luban
{
    public interface ITypeId
    {
        int GetTypeId();
    }
}
