return {
	name = "demo_parent",
	desc ="demo parent",
	parent_name = "",
	keys =
	{
		{name="v1",desc="v1 haha", is_static=false, key_type="BOOL", type_class_name=""},
	},
}