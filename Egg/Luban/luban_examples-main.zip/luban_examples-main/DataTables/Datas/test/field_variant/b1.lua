return {
    id = 4001,
    name = "b1",
    ["name@en"] = "b1_en",
    ["name@zh"] = "b1_zh",
}