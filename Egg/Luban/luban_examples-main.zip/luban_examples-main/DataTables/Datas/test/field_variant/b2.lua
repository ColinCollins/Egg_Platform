return {
    id = 4002,
    name = "b1",
    ["name@en"] = "b1_en",
    ["name@zh"] = "b1_zh",
}