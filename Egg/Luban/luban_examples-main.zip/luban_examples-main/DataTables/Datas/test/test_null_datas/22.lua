return
{
	id=22,
	x1 = 1,
	x2 = "B",
	x3 = {x1=3},
	x4 = {__type__="DemoD2", x1=1, x2=2},
	s1 = "asfs",
	s2 = "/abc",
}