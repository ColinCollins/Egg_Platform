return {
	__tag__ = "test",
	id = 102,
	value="test",
}